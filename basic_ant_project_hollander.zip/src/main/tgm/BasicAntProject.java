package tgm;

public class BasicAntProject {
  public static void main(String[] args) {
    BasicAntProject bap = new BasicAntProject();
    System.out.println(bap.getStringToPrint());
  }

  public String getStringToPrint() {
    return "Hello World!";
  }
}
